﻿using System;

namespace TrusteeShipAOP.Core.Attribute
{
    [System.AttributeUsage(AttributeTargets.Method | AttributeTargets.Property, AllowMultiple = true, Inherited = false)]
    public class MPAspectAttribute : System.Attribute
    {
        //[Obsolete("函数暂未生效！")]//警告
        //[Obsolete("函数暂未生效！", true)]//错误
        public virtual void OnException(object sender, AspectEventArgs args, Exception ex)
        { 
        }

        //[Obsolete("函数暂未生效！")]//警告
        //[Obsolete("函数暂未生效！", true)]//错误
        public virtual void OnExceptionFinally(object sender, AspectEventArgs args)
        {
        }

        public virtual void OnEntry(object sender, AspectEventArgs args) { }

        public virtual void OnExit(object sender, AspectEventArgs args) { }

        public virtual bool Validating(object sender, AspectEventArgs args)
        {
            return true;
        }
    }

    public class AspectEventArgs : EventArgs
    {
        public string MethodFullName { get; set; }
        public string MethodName { get; set; }
        public string Name { get; set; }
        public bool IsProperty { get; set; }
        public PropertyMethodType PropertyMethodType { get; set; } = PropertyMethodType.UnKnow;
        public object[] Params { get; set; }
    }

    public enum PropertyMethodType
    {
        UnKnow,
        Get,
        Set
    }
}
