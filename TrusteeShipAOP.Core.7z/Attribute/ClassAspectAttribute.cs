﻿using System;

namespace TrusteeShipAOP.Core.Attribute
{
    [System.AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = false)]
    public sealed class ClassAspectAttribute : System.Attribute
    {
    }
}
